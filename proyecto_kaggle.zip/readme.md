# Exploracion de datasets
Se realizara la exploracion de un dataset de Kaggle donde se normalizara la informacion mediante pandas en un
Jupyter notebook y se cargara en una base de datos con el ORM SQLAlchemy.